var classavr_pattern =
[
    [ "avrPattern", "classavr_pattern.html#aa4e74ed9a12e743548d9bf880aecc185", null ],
    [ "avrPattern", "classavr_pattern.html#a05f2998048e17c4c0c9aad6f602f11b1", null ],
    [ "accuracy", "classavr_pattern.html#a212a6fc4a9acab9ae06a5fcab82b9c0d", null ],
    [ "center", "classavr_pattern.html#aead37a67a2a0ff500b071bd9bafa7c15", null ],
    [ "id", "classavr_pattern.html#a1d5dc06248a365f6acdef536ae783bf5", null ],
    [ "name", "classavr_pattern.html#ab038de2d8ebc3633cd5bbd55d18298a1", null ],
    [ "pos3D", "classavr_pattern.html#affbc11f7ae1f22c9a9fefb855bd6e5b4", null ],
    [ "setAccuracy", "classavr_pattern.html#a990cea7c04156ce2fcbe7295bdc0da80", null ],
    [ "setCenter", "classavr_pattern.html#af91b558c29fde6b897821dd48cf82c9f", null ],
    [ "setID", "classavr_pattern.html#a148de7180212abbdfa81431507c40a9b", null ],
    [ "setName", "classavr_pattern.html#acd22f88723f72538e1361ec676443c53", null ],
    [ "setVisible", "classavr_pattern.html#a5f2fa1a6320d44764adfbb8c6e074b87", null ],
    [ "setWidth", "classavr_pattern.html#ae77864f7a3e4c247226f87fa0a4b2693", null ],
    [ "trans", "classavr_pattern.html#acbc53b3ae2caa39e890db118045e09f2", null ],
    [ "visible", "classavr_pattern.html#afd677bd736475b0975371795a7bb0209", null ],
    [ "width", "classavr_pattern.html#acfa3004188b0e188856d99e16b845009", null ]
];