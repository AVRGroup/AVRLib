var classavr_system_multi =
[
    [ "avrSystemMulti", "classavr_system_multi.html#a5c2395b00dfbcfc5fe8381131997901a", null ],
    [ "avrSystemMulti", "classavr_system_multi.html#aeef640459bbbd037d6d64ce9587c37d6", null ],
    [ "drawFunction", "classavr_system_multi.html#a0c32328ce187e8c040ed7ac0ae10ceeb", null ],
    [ "setCameraTransformation", "classavr_system_multi.html#a96fe92b1d7cc08dfb4e8f57d7f0c7d17", null ],
    [ "setDisplayCallback", "classavr_system_multi.html#afa378d6fb53f7ee831e1f4acb6214eeb", null ],
    [ "setDisplayCallback", "classavr_system_multi.html#ae477c6fd28db9f09c98b71def0e5c041", null ],
    [ "setObjectTransformation", "classavr_system_multi.html#adeba14fe5306c1c6aad82b2c5103fadf", null ],
    [ "drawFunc", "classavr_system_multi.html#afb9a6363fb5550c6a180fa1a42a5d7c1", null ],
    [ "drawFunc2", "classavr_system_multi.html#ab1bc1f44dc7b9a3438355ed8a0ef5f65", null ]
];