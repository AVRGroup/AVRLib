var hierarchy =
[
    [ "avrApplication", "classavr_application.html", null ],
    [ "avrMatrix", "classavr_matrix.html", [
      [ "avrMatrix3x4", "classavr_matrix3x4.html", null ]
    ] ],
    [ "avrPattern", "classavr_pattern.html", null ],
    [ "avrPatternInfo", "classavr_pattern_info.html", null ],
    [ "avrSystemMarker", "classavr_system_marker.html", [
      [ "avrSystemAutoMulti", "classavr_system_auto_multi.html", null ],
      [ "avrSystemMulti", "classavr_system_multi.html", null ],
      [ "avrSystemSingle", "classavr_system_single.html", null ]
    ] ]
];