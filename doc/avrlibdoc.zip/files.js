var files =
[
    [ "avrApplication.h", "avr_application_8h_source.html", null ],
    [ "avrMatrix.h", "avr_matrix_8h_source.html", null ],
    [ "avrMatrix3x4.h", "avr_matrix3x4_8h_source.html", null ],
    [ "avrPattern.h", "avr_pattern_8h_source.html", null ],
    [ "avrPatternInfo.h", "avr_pattern_info_8h_source.html", null ],
    [ "avrSystemAutoMulti.h", "avr_system_auto_multi_8h_source.html", null ],
    [ "avrSystemMarker.h", "avr_system_marker_8h_source.html", null ],
    [ "avrSystemMulti.h", "avr_system_multi_8h_source.html", null ],
    [ "avrSystemSingle.h", "avr_system_single_8h_source.html", null ]
];