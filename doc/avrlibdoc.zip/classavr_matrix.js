var classavr_matrix =
[
    [ "avrMatrix", "classavr_matrix.html#aed0ad26350da0cb909833233d4f0b8e0", null ],
    [ "avrMatrix", "classavr_matrix.html#a46991bd48c86dae9b1d8a987381e1401", null ],
    [ "~avrMatrix", "classavr_matrix.html#a496795020901d5d5a42b3c51a2cdf4a0", null ],
    [ "access", "classavr_matrix.html#a24e5e23cfcba9774ce4a10d8a027b622", null ],
    [ "add", "classavr_matrix.html#a242c461dc5189ba5ea51d7de92b50eea", null ],
    [ "column", "classavr_matrix.html#a87a5d5fee3d3f8ff1970d077eee52ce5", null ],
    [ "determinant", "classavr_matrix.html#a778cdf2fd6644178cc0d43a6c9ff439c", null ],
    [ "inverse", "classavr_matrix.html#a5513ce11445f37491ae0aff012959498", null ],
    [ "matrix", "classavr_matrix.html#af06d1669ec6c8f2be5e2d2cf421e1dcd", null ],
    [ "operator*", "classavr_matrix.html#a005b285625ae8e9c677cde1c42309c71", null ],
    [ "operator*", "classavr_matrix.html#a90beb569a126464ac64d17a3a86d2b32", null ],
    [ "operator+", "classavr_matrix.html#ab0a3eb564d518e9bb19423e38225d5ab", null ],
    [ "operator-", "classavr_matrix.html#a158008cbe2eca3d0b7eae73354b8e85a", null ],
    [ "operator=", "classavr_matrix.html#ad3ab687c2493bf5729923091794b6a58", null ],
    [ "print", "classavr_matrix.html#a28dd43731f25153dff0a121004f23d34", null ],
    [ "row", "classavr_matrix.html#a3e27175e91c4565f66ec6e590fc86520", null ],
    [ "setIdentityMatrix", "classavr_matrix.html#a309f5af755f83a47327e6e88034d0680", null ],
    [ "trasposed", "classavr_matrix.html#ac7e10b075dfcc8a35ef001cb053580d0", null ],
    [ "matrixx", "classavr_matrix.html#acc47cfe71e4829cae8a64b29c15463da", null ]
];