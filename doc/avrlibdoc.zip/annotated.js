var annotated =
[
    [ "avrApplication", "classavr_application.html", "classavr_application" ],
    [ "avrMatrix", "classavr_matrix.html", "classavr_matrix" ],
    [ "avrMatrix3x4", "classavr_matrix3x4.html", "classavr_matrix3x4" ],
    [ "avrPattern", "classavr_pattern.html", "classavr_pattern" ],
    [ "avrPatternInfo", "classavr_pattern_info.html", "classavr_pattern_info" ],
    [ "avrSystemAutoMulti", "classavr_system_auto_multi.html", "classavr_system_auto_multi" ],
    [ "avrSystemMarker", "classavr_system_marker.html", "classavr_system_marker" ],
    [ "avrSystemMulti", "classavr_system_multi.html", "classavr_system_multi" ],
    [ "avrSystemSingle", "classavr_system_single.html", "classavr_system_single" ]
];