var searchData=
[
  ['trasposed',['trasposed',['../classavr_matrix.html#ac7e10b075dfcc8a35ef001cb053580d0',1,'avrMatrix']]]
];
