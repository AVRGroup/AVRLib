var searchData=
[
  ['numberpatts',['numberPatts',['../classavr_application.html#a6bb369dd9daf3ad30d5aad4808bdcd06',1,'avrApplication']]]
];
