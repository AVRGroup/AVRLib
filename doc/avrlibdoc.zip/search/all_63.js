var searchData=
[
  ['column',['column',['../classavr_matrix.html#a87a5d5fee3d3f8ff1970d077eee52ce5',1,'avrMatrix::column()'],['../classavr_matrix3x4.html#ad5a7117cf1ded88dfb8dd01cb12aa6e9',1,'avrMatrix3x4::column()']]]
];
