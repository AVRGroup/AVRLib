var classavr_pattern_info =
[
    [ "area", "classavr_pattern_info.html#a3a0093ce9ac05bb2745a1fa682a23438", null ],
    [ "cf", "classavr_pattern_info.html#a3890f6ae1571597f3ce6a18ce88f07a5", null ],
    [ "dir", "classavr_pattern_info.html#a1dd7c2ee70ebee15851798a6e140d2aa", null ],
    [ "id", "classavr_pattern_info.html#af72af1ef28567a03f9c14790e50caba3", null ],
    [ "line", "classavr_pattern_info.html#a877d45bbae69bc4a70fcd83fed56c316", null ],
    [ "pos", "classavr_pattern_info.html#a9a6b2c6270b15d0df992c1b97eb1ebd9", null ],
    [ "vertex", "classavr_pattern_info.html#a81b663e52fb6304d7a8803ba1149d2f8", null ]
];