var struct_a_r_vec =
[
    [ "clm", "struct_a_r_vec.html#ada4635dbe21fb30b3787e5171ecfbb74", null ],
    [ "v", "struct_a_r_vec.html#a8b9f960f11cc40498b2b525dad100450", null ]
];