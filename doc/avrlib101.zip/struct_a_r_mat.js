var struct_a_r_mat =
[
    [ "clm", "struct_a_r_mat.html#a87acc8f1caab5cf519ec7566325915ae", null ],
    [ "m", "struct_a_r_mat.html#a3b919177e92815e987b07ab165da01a7", null ],
    [ "row", "struct_a_r_mat.html#a0160fe7dfa8111eed279781649c5549a", null ]
];