var classavr_system_auto_multi =
[
    [ "avrSystemAutoMulti", "classavr_system_auto_multi.html#a7e37ab80a1ec1a925d958e38639ced46", null ],
    [ "avrSystemAutoMulti", "classavr_system_auto_multi.html#ad4f6d236dc89844ae047211ea9162dcb", null ],
    [ "~avrSystemAutoMulti", "classavr_system_auto_multi.html#a23fa075590c1596cd1b912df4c6905ac", null ],
    [ "drawFunction", "classavr_system_auto_multi.html#a030a805955fcc90a8082fcb12ad9a80f", null ],
    [ "getHolderMarker", "classavr_system_auto_multi.html#a026bfb4ca356b64cf9415a6035335251", null ],
    [ "getMainMarker", "classavr_system_auto_multi.html#a5505ab405750f53d912b5bb529aebe07", null ],
    [ "getPrevTransf", "classavr_system_auto_multi.html#ab3776d9d3a377e1f8ee130f5b427f641", null ],
    [ "getTransf", "classavr_system_auto_multi.html#a2120f522f8f9a9d02031db03c37bd925", null ],
    [ "initPointers", "classavr_system_auto_multi.html#a723717d68b81968cfe8d654f096383af", null ],
    [ "setCameraTransformation", "classavr_system_auto_multi.html#aa5fda68ead553d6146ef38f53d12a4ed", null ],
    [ "setDisplayCallback", "classavr_system_auto_multi.html#a4b34ac9e730e6942e82f3f17a5dd0bb6", null ],
    [ "setDisplayCallback", "classavr_system_auto_multi.html#adb5f93027373d9f360e2e8d20e1b1549", null ],
    [ "setMainMarker", "classavr_system_auto_multi.html#a99b5740990d70eb05961ee83a54f58f1", null ],
    [ "setObjectTransformation", "classavr_system_auto_multi.html#a8fc6be5311998a51056f8f4b2e443094", null ],
    [ "drawFunc", "classavr_system_auto_multi.html#a3bd075f84c739fc5778a46e6146b874e", null ],
    [ "drawFunc2", "classavr_system_auto_multi.html#a374678038af70f4436d7f45947d3cb76", null ]
];