var classavr_matrix3x4 =
[
    [ "avrMatrix3x4", "classavr_matrix3x4.html#a36e9773d69e4fa970f8d0e20524a9aa5", null ],
    [ "avrMatrix3x4", "classavr_matrix3x4.html#a391837f293aa73b064a41aca364d6a6b", null ],
    [ "avrMatrix3x4", "classavr_matrix3x4.html#a24029bcb2ccf15bc449287bc6fbe8b26", null ],
    [ "~avrMatrix3x4", "classavr_matrix3x4.html#ac631c76fdc9f41b65a6585e1e15230ab", null ],
    [ "access", "classavr_matrix3x4.html#a7782b5c0211411a41e5293b038974ff1", null ],
    [ "add", "classavr_matrix3x4.html#a4e47d85232a5abe1ccc8cd0ba72e4e18", null ],
    [ "column", "classavr_matrix3x4.html#a1a4b9dbfa01c671406e31452da182875", null ],
    [ "euclidianDistanceBetween", "classavr_matrix3x4.html#ac05ea22d8597df4aa2b1f261ec94f8a7", null ],
    [ "extractQuatAndPos", "classavr_matrix3x4.html#aa48c0f1da93a4aeb29750e8f2a06d968", null ],
    [ "getMatrixGLFormat", "classavr_matrix3x4.html#ad03865e565b36b5e60057247216d901e", null ],
    [ "getRelationWith", "classavr_matrix3x4.html#af6aeaea8801d27ad4aec3c1fc9aea277", null ],
    [ "matrix", "classavr_matrix3x4.html#ab51a103b8c059a18324d4c675a47a0fa", null ],
    [ "operator*", "classavr_matrix3x4.html#a69695710fa229029aac327a93bf67e28", null ],
    [ "operator=", "classavr_matrix3x4.html#a1df7a480b6c33d08d2151f513bc7541b", null ],
    [ "print", "classavr_matrix3x4.html#a5a420d32fd603ba922472c5777dbc4cb", null ],
    [ "row", "classavr_matrix3x4.html#af5c3bc76237bca8a83dd79f62464dba3", null ],
    [ "setMatWithQuatAndPos", "classavr_matrix3x4.html#a2cace74000dc095ad78c7dca07804a18", null ],
    [ "X", "classavr_matrix3x4.html#a6af1e8d00de2afc425f86c6c9db7c45a", null ],
    [ "Y", "classavr_matrix3x4.html#a4fa40ec6eef8c249a3ee09191ec1f6e7", null ],
    [ "Z", "classavr_matrix3x4.html#a2ea62d9f789f86593d9e52e552775821", null ]
];