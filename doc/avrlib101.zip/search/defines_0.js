var searchData=
[
  ['ar_5fdll_5fapi',['AR_DLL_API',['../avr_video_8h.html#adf389af59588886ab4fad5c4c5c447cd',1,'avrVideo.h']]],
  ['arelem0',['ARELEM0',['../avr_math_8h.html#a7a935ae1197adde7e3476dbfbfc4f99e',1,'avrMath.h']]],
  ['arelem1',['ARELEM1',['../avr_math_8h.html#af33714038d5eb3748816c2361af9d7b2',1,'avrMath.h']]],
  ['armalloc',['arMalloc',['../avr_util_8h.html#a8f604950d2f084c26c5536d3f3c6d2dc',1,'avrUtil.h']]]
];
