var searchData=
[
  ['width',['width',['../classavr_pattern.html#acfa3004188b0e188856d99e16b845009',1,'avrPattern']]]
];
