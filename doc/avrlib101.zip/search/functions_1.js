var searchData=
[
  ['center',['center',['../classavr_pattern.html#aead37a67a2a0ff500b071bd9bafa7c15',1,'avrPattern']]],
  ['column',['column',['../classavr_matrix.html#a76a17536f9dc8cb8a36bb1a6d0a1e450',1,'avrMatrix::column()'],['../classavr_matrix3x4.html#a1a4b9dbfa01c671406e31452da182875',1,'avrMatrix3x4::column()']]]
];
