var searchData=
[
  ['name',['name',['../classavr_pattern.html#ab038de2d8ebc3633cd5bbd55d18298a1',1,'avrPattern']]],
  ['numberpatts',['numberPatts',['../classavr_application.html#a6bb369dd9daf3ad30d5aad4808bdcd06',1,'avrApplication']]]
];
