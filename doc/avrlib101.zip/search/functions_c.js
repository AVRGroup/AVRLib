var searchData=
[
  ['trans',['trans',['../classavr_pattern.html#acbc53b3ae2caa39e890db118045e09f2',1,'avrPattern']]],
  ['transposed',['transposed',['../classavr_matrix.html#af5758a4a5202f020619d0c8d2db3f47f',1,'avrMatrix']]]
];
