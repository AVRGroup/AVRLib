var searchData=
[
  ['euclidiandistancematrix3x4',['euclidianDistanceMatrix3x4',['../avr_math_8h.html#a570a0d36500688e7370de5981d00f658',1,'avrMath.h']]],
  ['euclidiandistancevector3',['euclidianDistanceVector3',['../avr_math_8h.html#ab706eb7d808535e482df62e1275c5087',1,'avrMath.h']]]
];
