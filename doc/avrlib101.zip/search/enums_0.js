var searchData=
[
  ['base_5fselection_5fmode',['BASE_SELECTION_MODE',['../avr_system_auto_multi_8h.html#ab3e44c47c79ea96f84d2182417bd945f',1,'avrSystemAutoMulti.h']]]
];
