var searchData=
[
  ['copymatrix3x4',['copyMatrix3x4',['../avr_math_8h.html#a9354e8664195f8eee580487baae52964',1,'avrMath.h']]]
];
