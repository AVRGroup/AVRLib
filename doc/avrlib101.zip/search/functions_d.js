var searchData=
[
  ['visible',['visible',['../classavr_pattern.html#afd677bd736475b0975371795a7bb0209',1,'avrPattern']]]
];
