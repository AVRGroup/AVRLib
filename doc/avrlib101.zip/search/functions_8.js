var searchData=
[
  ['operator_2a',['operator*',['../classavr_matrix.html#a005b285625ae8e9c677cde1c42309c71',1,'avrMatrix::operator*(const avrMatrix &amp;)'],['../classavr_matrix.html#a90beb569a126464ac64d17a3a86d2b32',1,'avrMatrix::operator*(double scalar)'],['../classavr_matrix3x4.html#a69695710fa229029aac327a93bf67e28',1,'avrMatrix3x4::operator*()']]],
  ['operator_2b',['operator+',['../classavr_matrix.html#ab0a3eb564d518e9bb19423e38225d5ab',1,'avrMatrix']]],
  ['operator_2d',['operator-',['../classavr_matrix.html#a158008cbe2eca3d0b7eae73354b8e85a',1,'avrMatrix']]],
  ['operator_3d',['operator=',['../classavr_matrix.html#ad3ab687c2493bf5729923091794b6a58',1,'avrMatrix::operator=()'],['../classavr_matrix3x4.html#a1df7a480b6c33d08d2151f513bc7541b',1,'avrMatrix3x4::operator=()']]],
  ['operator_5b_5d',['operator[]',['../classavr_matrix.html#a66671c05393112b5d5169f836fb7905a',1,'avrMatrix']]]
];
