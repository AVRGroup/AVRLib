var searchData=
[
  ['patts',['patts',['../classavr_system_marker.html#a979bc77ea440bbdf9fe5737164925450',1,'avrSystemMarker']]],
  ['pos',['pos',['../classavr_pattern_info.html#a9a6b2c6270b15d0df992c1b97eb1ebd9',1,'avrPatternInfo']]],
  ['projection',['projection',['../classavr_system_marker.html#a5e7a6a94a0286fc7b60af9e961dc73a7',1,'avrSystemMarker']]]
];
