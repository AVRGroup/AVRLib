var searchData=
[
  ['id',['id',['../classavr_pattern_info.html#af72af1ef28567a03f9c14790e50caba3',1,'avrPatternInfo']]]
];
