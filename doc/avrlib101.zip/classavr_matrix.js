var classavr_matrix =
[
    [ "avrMatrix", "classavr_matrix.html#aed0ad26350da0cb909833233d4f0b8e0", null ],
    [ "avrMatrix", "classavr_matrix.html#a46991bd48c86dae9b1d8a987381e1401", null ],
    [ "~avrMatrix", "classavr_matrix.html#a496795020901d5d5a42b3c51a2cdf4a0", null ],
    [ "access", "classavr_matrix.html#ae567564e98ed62ac6d590cad43f67f15", null ],
    [ "add", "classavr_matrix.html#af897a6e550bc75012b8314d5d73370a5", null ],
    [ "column", "classavr_matrix.html#a76a17536f9dc8cb8a36bb1a6d0a1e450", null ],
    [ "determinant", "classavr_matrix.html#a778cdf2fd6644178cc0d43a6c9ff439c", null ],
    [ "inverse", "classavr_matrix.html#a5513ce11445f37491ae0aff012959498", null ],
    [ "matrix", "classavr_matrix.html#af06d1669ec6c8f2be5e2d2cf421e1dcd", null ],
    [ "operator*", "classavr_matrix.html#a005b285625ae8e9c677cde1c42309c71", null ],
    [ "operator*", "classavr_matrix.html#a90beb569a126464ac64d17a3a86d2b32", null ],
    [ "operator+", "classavr_matrix.html#ab0a3eb564d518e9bb19423e38225d5ab", null ],
    [ "operator-", "classavr_matrix.html#a158008cbe2eca3d0b7eae73354b8e85a", null ],
    [ "operator=", "classavr_matrix.html#ad3ab687c2493bf5729923091794b6a58", null ],
    [ "operator[]", "classavr_matrix.html#a66671c05393112b5d5169f836fb7905a", null ],
    [ "print", "classavr_matrix.html#a28dd43731f25153dff0a121004f23d34", null ],
    [ "row", "classavr_matrix.html#af1ae62e6a572e006af25423303c6cfca", null ],
    [ "setIdentityMatrix", "classavr_matrix.html#a309f5af755f83a47327e6e88034d0680", null ],
    [ "transposed", "classavr_matrix.html#af5758a4a5202f020619d0c8d2db3f47f", null ],
    [ "data", "classavr_matrix.html#a6569f439b5fb666641fe664d4454d0e8", null ]
];