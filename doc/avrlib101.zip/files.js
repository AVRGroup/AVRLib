var files =
[
    [ "avrApplication.h", "avr_application_8h.html", [
      [ "avrApplication", "classavr_application.html", "classavr_application" ]
    ] ],
    [ "avrGraphics.h", "avr_graphics_8h.html", "avr_graphics_8h" ],
    [ "avrMath.h", "avr_math_8h.html", "avr_math_8h" ],
    [ "avrMatrix.h", "avr_matrix_8h.html", [
      [ "avrMatrix", "classavr_matrix.html", "classavr_matrix" ]
    ] ],
    [ "avrMatrix3x4.h", "avr_matrix3x4_8h.html", [
      [ "avrMatrix3x4", "classavr_matrix3x4.html", "classavr_matrix3x4" ]
    ] ],
    [ "avrParameters.h", "avr_parameters_8h.html", "avr_parameters_8h" ],
    [ "avrPattern.h", "avr_pattern_8h.html", [
      [ "avrPattern", "classavr_pattern.html", "classavr_pattern" ]
    ] ],
    [ "avrPatternInfo.h", "avr_pattern_info_8h.html", [
      [ "avrPatternInfo", "classavr_pattern_info.html", "classavr_pattern_info" ]
    ] ],
    [ "avrSystemAutoMulti.h", "avr_system_auto_multi_8h.html", "avr_system_auto_multi_8h" ],
    [ "avrSystemMarker.h", "avr_system_marker_8h.html", [
      [ "avrSystemMarker", "classavr_system_marker.html", "classavr_system_marker" ]
    ] ],
    [ "avrSystemMulti.h", "avr_system_multi_8h.html", [
      [ "avrSystemMulti", "classavr_system_multi.html", "classavr_system_multi" ]
    ] ],
    [ "avrSystemSingle.h", "avr_system_single_8h.html", [
      [ "avrSystemSingle", "classavr_system_single.html", "classavr_system_single" ]
    ] ],
    [ "avrUtil.h", "avr_util_8h.html", "avr_util_8h" ],
    [ "avrVideo.h", "avr_video_8h.html", "avr_video_8h" ],
    [ "avrVision.h", "avr_vision_8h.html", "avr_vision_8h" ]
];