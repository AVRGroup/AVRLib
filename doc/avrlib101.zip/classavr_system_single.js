var classavr_system_single =
[
    [ "avrSystemSingle", "classavr_system_single.html#a2b076754388066547d98c31d67085dc2", null ],
    [ "avrSystemSingle", "classavr_system_single.html#a0e92b9719379fa42ff820c61449edfb0", null ],
    [ "drawFunction", "classavr_system_single.html#a6664aa63cfc119ef461de3b24b03bda5", null ],
    [ "setCameraTransformation", "classavr_system_single.html#a295e942652e83adac2305ce58fe12bdd", null ],
    [ "setDisplayCallback", "classavr_system_single.html#a796f9552387f638896c154aee433c511", null ],
    [ "setDisplayCallback", "classavr_system_single.html#a85f602cb791f1e9f6453df363cc1ff6d", null ],
    [ "setObjectTransformation", "classavr_system_single.html#a8b87bd9c86e02427ea210eac6ffc45ea", null ],
    [ "drawFunc", "classavr_system_single.html#a1b9aa46cfd25de274c7375439ef75339", null ],
    [ "drawFunc2", "classavr_system_single.html#a7ea216b2e44684e7bec21e8dbdf6f797", null ]
];