var avr_video_8h =
[
    [ "AR_DLL_API", "avr_video_8h.html#adf389af59588886ab4fad5c4c5c447cd", null ],
    [ "arVideoCapNext", "avr_video_8h.html#a2046b769eb5c401dcb21c210207752bb", null ],
    [ "arVideoCapStart", "avr_video_8h.html#a488a6c18e106ef1543a1d2a0e17de91a", null ],
    [ "arVideoCapStop", "avr_video_8h.html#ac76f6bf870224d71783c07e9c0c425a9", null ],
    [ "arVideoClose", "avr_video_8h.html#a635906a4da8d95ef6813d89190211da0", null ],
    [ "arVideoDispOption", "avr_video_8h.html#a0e9d9ba5508b3f0ee5b542f47d7306e5", null ],
    [ "arVideoGetImage", "avr_video_8h.html#a85908767d56fd5e7918254a931a7358d", null ],
    [ "arVideoInqSize", "avr_video_8h.html#ae998292f3bf2e5cc8440e084f9d63e81", null ],
    [ "arVideoOpen", "avr_video_8h.html#a71c85a73046c9ebb3f733ea36ca521c2", null ]
];